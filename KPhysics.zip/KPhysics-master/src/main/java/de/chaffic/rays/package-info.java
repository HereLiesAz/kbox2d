/**
 * Package containing all classes relating to the use of rays.
 */
package de.chaffic.rays;