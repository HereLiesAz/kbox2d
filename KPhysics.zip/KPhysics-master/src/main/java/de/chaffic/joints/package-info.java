/**
 * Package containing all classes relating to joints.
 */
package de.chaffic.joints;