package de.chaffic.geometry.bodies

import de.chaffic.math.Vec2

interface TranslatableBody {
    var position: Vec2
}