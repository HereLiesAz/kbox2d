/**
 * Package containing all classes relating to geometric constructs.
 */
package de.chaffic.geometry;