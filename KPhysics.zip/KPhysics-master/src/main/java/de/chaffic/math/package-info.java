/**
 * Package containing all classes relating to mathematical constructs.
 */
package de.chaffic.math;