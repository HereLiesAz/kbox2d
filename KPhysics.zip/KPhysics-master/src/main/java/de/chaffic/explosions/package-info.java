/**
 * Package containing all classes relating to explosions.
 */
package de.chaffic.explosions;