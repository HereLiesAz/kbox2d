/**
 * Package containing all classes relating to collisions and contacts.
 */
package de.chaffic.collision;