/**
 * Package containing all classes that handle physical properties and interactions.
 */
package de.chaffic.dynamics;